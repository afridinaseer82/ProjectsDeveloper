import java.util.Scanner;

public class Shopping_Basket {
	Scanner scr=new Scanner(System.in);
	private int ItemList = 0;
	private int Items_Remove,Items_Add;
	public String Yes_or_No;
	
	
	public Shopping_Basket()
	{
		System.out.println("Are You looking for Shopping?");
		System.out.println("Please Enter (Yes/No) ");
		this.Yes_or_No = scr.next();	
	}

	public void Add_Items()
	{
		System.out.println("");
		System.out.println("How Many Items You Want to Add?");
		this.Items_Add = scr.nextInt();
		this.ItemList+=this.Items_Add;
		System.out.println("Items in the Basket: " + this.ItemList);
		System.out.println("");
	}
	
	public void Remove_items()
	{
		if (this.ItemList!=0)
		{
			System.out.println("");
			System.out.println("You have " + this.ItemList + " items in Your Basket");
			System.out.println("Please Enter How Many Items You want To Delete? ");
			this.Items_Remove = scr.nextInt();
			
			
			if ( this.Items_Remove> this.ItemList)
			{
				String ch = "yes";
				System.out.println("Warning: you are deleting: " + this.Items_Remove + " & your Basket contain " + this.ItemList + " Items");
				System.out.println("Do You Want to Try Again? (Yes/NO)");
				ch=scr.next();
				
				while(!ch.equalsIgnoreCase("no"))
				{
					System.out.println("");
					System.out.println("You have " + this.ItemList + " items in Your Basket");
					System.out.println("Please Enter How Many Items You want To Delete? ");
					this.Items_Remove = scr.nextInt();
					
					if((this.Items_Remove== this.ItemList) ^ (this.Items_Remove<this.ItemList))
					{
						ch="no";
						this.ItemList-=this.Items_Remove;
						
					}
					
					else
						
					{
						ch="yes";
					}
				}
			}
			
			else 
				
			{
				this.ItemList-=this.Items_Remove;
			}
			
		}
		
		else
			
		{
			System.out.println("");
			System.out.println("Sorry Your Bag is Empty! ");
			System.out.println("");
		}
	}
	
	public void Calculate_Items()
	{
		if (this.ItemList==0)
		{
			System.out.println("");
			System.out.println("No Items in the Bag !!");
			System.out.println("");
		}
		
		else
			
		{
			System.out.println("");
			System.out.println("Totel Items in the Bag is : " + this.ItemList);
			System.out.println("");
		}
	}
	
	public void Empty_Shopping_Basket()
	{
		this.ItemList*=0;
		System.out.println("Your Basket is Empty Now & Contain " + this.ItemList + " item");
		System.out.println("");
	}
	
}
