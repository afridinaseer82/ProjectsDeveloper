import java.util.Scanner;

public class Shopping_Basket_Tasks {

	public static void main(String[] args) {
		
		Scanner scr=new Scanner(System.in);
		Shopping_Basket sb = new Shopping_Basket();
		String check;
		String n = "yes";
		
		
		 if(!sb.Yes_or_No.equalsIgnoreCase("yes"))
			{
					System.out.println("Sorry See you Next Time");
			}
		 
		 else if(!sb.Yes_or_No.equalsIgnoreCase("no"))
		 {
			 while ( !n.equalsIgnoreCase("No"))
			 {
				
				 	System.out.println("<<----------------Welcome to your Basket --------------->>");
				 	System.out.println("");
			 		System.out.println("1): Please Enter A for Add Items ");
			 		System.out.println("2): R for Remove Items");
			 		System.out.println("3): E for Empty the Basket");
			 		System.out.println("4): C for Calculate the Items");
			 		check= scr.next();
		
			 		if (check.equalsIgnoreCase("A"))
			 		{
			 			sb.Add_Items();
			 		}
			 		else if (check.equalsIgnoreCase("R"))
			 		{	
			 			sb.Remove_items();
			 		}
			 		else if (check.equalsIgnoreCase("C"))
			 		{
			 			sb.Calculate_Items();
			 		}
			 		else if (check.equalsIgnoreCase("E"))
			 		{
			 			sb.Empty_Shopping_Basket();
			 		}
			 	System.out.println("Anything Else You want to do with the Basktet?");
			 	System.out.println(" Yes/NO");
			 	n=scr.next();
			 	
			 	if ( n.equalsIgnoreCase("no"))
			 	{
			 		System.out.println("GoodBye See You Soon");
			 		break;
			 	}
			 		
			 }
		 }
		 else
		 {
			 System.out.println("Warning: Invalid option Selected!!");
		 }
	}
}
